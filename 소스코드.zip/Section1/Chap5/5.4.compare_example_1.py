#5.4.compare_example_1.py 

str1 = "ACGT" 
str2 = "ACGT" 

print(str1)  # ACGT 가 출력된다.
print(str2)  # ACGT 가 출력된다.
print(str1 == str2)  # True 가 출력된다.

