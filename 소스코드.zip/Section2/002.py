#002.py
r = 3
PI = 3.14
area = r * r * PI
print(area)
