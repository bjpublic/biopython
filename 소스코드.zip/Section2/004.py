#004.py
num1 = 3
if num1 % 2 == 1:
    print(num1, "은 홀수다.")
else:
    print(num1, "은 짝수다.")
