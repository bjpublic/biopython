#007.py
for i in range(2,9,2):
    for j in range(1,10,1):
        print(i, "*", j, "=", i*j)
