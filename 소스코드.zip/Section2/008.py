#008.py
num = 5
result = 1

while num > 0:
    result *= num
    num -= 1

print(result)
