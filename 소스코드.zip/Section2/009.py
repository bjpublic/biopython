#009.py

def greet():
    print("Hello, Bioinformatics")
    
greet()
greet()
