#010.py

def mySum(num1, num2):
    print("%s + %s = %s" %(num1, num2, num1+num2))
    
mySum(2, 3)
mySum(5, 7)
mySum(10,15)
