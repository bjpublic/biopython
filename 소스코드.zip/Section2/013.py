#013.py

name = input("이름 입력: ")
print("Hello %s." % name)
