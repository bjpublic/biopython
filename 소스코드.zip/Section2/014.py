#014.py

s = input("입력: ")
if s.isalpha():
    print("%s는 문자." % s)
else:
    print("%s는 숫자." % s)
