#015.py

import sys

s = sys.argv[1]
print("Hello %s" % s)
