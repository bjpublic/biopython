#017-1.py
f = open("write_sample.txt",'w')
f.write("Hello\n")
f.write("write_sample text file\n")
f.close()
