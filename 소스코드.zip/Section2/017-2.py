#017-2.py
with open("write_sample.txt",'w') as handle:
    handle.write("Hello\n")
    handle.write("write_sample text file\n")

