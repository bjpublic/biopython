#019_before.py
with open("noname.txt",'r') as fr:
    read = fr.readlines()
    print(read)

