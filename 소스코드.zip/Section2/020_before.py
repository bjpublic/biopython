#020_before.py
num = int(input("Enter: "))
print(10 / num)
