#021.py

a = "Bio"
b = "Informatics"
c = a + b

print(c)
