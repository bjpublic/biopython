#022.py

Met = "ATG"
Trp = "TGG" * 10
His = "CAT"

seq = Met + Trp + His
print(seq)
