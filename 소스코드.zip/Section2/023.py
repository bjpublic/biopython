#023.py

seq = "AGTTTATAG"
print(seq[5])
