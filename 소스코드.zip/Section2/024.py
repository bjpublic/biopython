#024.py

seq = "AGTTTATAG"
print(seq[3:6])
