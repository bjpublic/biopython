#025.py

seq = "AGTTTATAG"
print(len(seq))
