#026.py

seq = "ATGttATaG"
print(seq.upper())
print(seq.lower())
