#028.py

seq = "AGTTTATAG"
for i in range(0,len(seq),3):
    print(seq[i:i+3])
