#029-2.py
seq = "AGTTTATAG"
print(seq[::-1])
