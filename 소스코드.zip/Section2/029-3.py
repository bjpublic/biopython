#029-3.py
seq = "AGTTTATAG"
print(''.join(reversed(seq)))
