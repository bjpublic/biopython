#032.py

seq = "AGTTTATAG"
print("C" in seq)
print("T" in seq)
