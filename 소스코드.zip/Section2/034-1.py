#034-1.py

seq = "AGTTTATAG"
A = seq.count("A")
C = seq.count("C")
G = seq.count("G")
T = seq.count("T")

print("A:", A)
print("C:", C)
print("G:", G)
print("T:", T)

