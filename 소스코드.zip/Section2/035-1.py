#035-1.py

seq = "AGTTTATAG"
print(seq.replace("T", "U"))
