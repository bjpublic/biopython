#035-2.py

from Bio.Seq import Seq

seq = Seq("AGTTTATAG")
print(seq.transcribe())
