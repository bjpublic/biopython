#036.py

s = "Welcome to the Bioinformatics World!"
arr = s.split()
print(len(arr))
