#037-1.py

import math

n = 144
print(math.sqrt(144))
