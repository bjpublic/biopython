#037-2.py

import math

n = 144
print(math.pow(144, 0.5))
