#037-3.py

n = 144
print(n**0.5)
