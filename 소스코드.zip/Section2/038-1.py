#038-1.py

print(abs(10))
print(abs(-15))
