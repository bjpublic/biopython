#038-2.py

def get_absolute(n):
    if n >= 0:
        return n
    else:
        return -n
    
print(get_absolute(10))
print(get_absolute(-15))
