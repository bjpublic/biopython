#039.py

import math

print(math.log10(2))
