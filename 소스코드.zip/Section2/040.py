#040.py

import math

print(math.log(2))
