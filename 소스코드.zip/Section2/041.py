#041.py

import math

print(math.log(81, 3))
