#042.py

print(round(62.77779, 2))
