#043.py

print(round(78564, -3))
