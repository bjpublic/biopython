#044-1.py

from random import randint

for i in range(6):
    print(randint(1, 45))
