#044-2.py

from random import randrange

for i in range(6):
    print(randrange(1,45+1))
