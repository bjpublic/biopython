#052.py

a = [3, 5, 2, 1, 4]
b = [8, 10, 7, 6, 9]

print("sorted(a)")
print(sorted(a))
print("a")
print(a)

print("")
b.sort()
print("b.sort()")
print(b)
