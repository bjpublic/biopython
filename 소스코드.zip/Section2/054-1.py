#054-1.py

a = ["tree", "lake", "park"]
a.append("goose")

print(a)
