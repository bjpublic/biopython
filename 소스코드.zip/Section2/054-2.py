#054-2.py

a = ["tree", "lake", "park"]
a += ["goose"]

print(a)
