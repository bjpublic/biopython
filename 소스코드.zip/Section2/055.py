#055.py

a = ["tree", "lake", "park"]
a.insert(2, "goose")

print(a)
