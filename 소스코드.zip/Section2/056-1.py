#056-1.py

a = ["tree", "lake", "park"]
a.remove("lake")

print(a)
