#056-2.py

a = ["tree", "lake", "park"]
idx = a.index("lake")
a.pop(idx)

print(a)
