#057-1.py

a = ["tree", "lake", "park", "park", "lake", "lake"]

print(a.count("lake"))
