#057-2.py

a = ["tree", "lake", "park", "park", "lake", "lake"]

count = 0

for s in a:
    if s == "lake":
        count += 1
        
print(count)
