#059-1.py

a = [3, 5, 2, 1, 4]

print(min(a))
