#060-2.py

a = [3, 5, 2, 1, 4]

sum_val = 0

for i in a:
    sum_val += i

print(sum_val)
