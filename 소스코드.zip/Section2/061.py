#061.py

a = [3, 5, 2, 1, 4]

sum_val = sum(a)

print(sum_val/len(a))
