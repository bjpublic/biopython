#062.py
s = "a;b;c;d;e"

arr = s.split(";")

print(arr)
