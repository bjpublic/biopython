#063.py

arr = ['a', 'b', 'c', 'd', 'e']

s = ";".join(arr)

print(s)
