#064.py

from random import shuffle

a = [1, 2, 3, 4, 5]

shuffle(a)

print(a)
