#065.py

d = {"Leu": "L", "Met": "M", "Ser": "S"}

print(d)
