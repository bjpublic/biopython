#066-2.py

d = {}

key_list = ["Leu", "Met", "Ser"]
value_list = ["L", "M", "S"]

for i in range(len(key_list)):
    d[key_list[i]] = value_list[i]
    
print(d)
