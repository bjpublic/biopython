#067.py

d = {"Leu": "L", "Met": "M", "Ser": "S"}

del d["Met"]
print(d)
