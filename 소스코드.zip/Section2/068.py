#068.py

d = {"Leu": "L", "Met": "M", "Ser": "S"}

print("Met" in d)
print("Pro" in d)
