#074.py

arr1 = ["Ala", "Phe", "Phe", "Cys", "Ala", "Gly"]
arr2 = ["Phe", "Gly", "Gly", "Val", "Val", "Phe"]

s1 = set(arr1)
print(s1)

s2 = set(arr2)
print(s2)

