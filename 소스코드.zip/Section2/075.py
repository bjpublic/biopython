#075.py

s1 = {'Phe', 'Gly', 'Cys', 'Ala'}
s2 = {'Gly', 'Val', 'Phe'}

print(s1.union(s2))
