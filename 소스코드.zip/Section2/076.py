#076.py

s1 = {'Phe', 'Gly', 'Cys', 'Ala'}
s2 = {'Gly', 'Val', 'Phe'}

print(s1.intersection(s2))
