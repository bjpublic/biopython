#078.py

essential_aminoacids = ["Val", "Leu", "Ile", "Met", "Thr", "Lys", "Phe", "Trp"]
t = tuple(essential_aminoacids)

print(t)
