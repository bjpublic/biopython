#079.py

t = ('Val', 'Leu', 'Ile', 'Met', 'Thr', 'Lys', 'Phe', 'Trp')

print(t[1:4])
print(t.index("Lys"))
