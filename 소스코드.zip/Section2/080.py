#080.py

class MyClass:
    pass

obj = MyClass()
print(type(obj))
