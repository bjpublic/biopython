#081.py

class MyClass:
    base = ["A", "C", "G", "T"]

obj = MyClass()
print(obj.base)
