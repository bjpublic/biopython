#082.py

class MyClass:
    def get_length(self, seq):
        return len(seq)

obj = MyClass()
seq = "ACGTACGT"
print(obj.get_length(seq))

